package com.candidjava.spring.boot.helloworld.model;

public class TestObjectPrime {
	private boolean onePrime;

	public boolean getOnePrime() {
		return onePrime;
	}

	public void setOnePrime(boolean onePrime) {
		this.onePrime = onePrime;
	}

}
