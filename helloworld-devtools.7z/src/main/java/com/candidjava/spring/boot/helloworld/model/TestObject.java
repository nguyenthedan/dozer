package com.candidjava.spring.boot.helloworld.model;

public class TestObject {
	private String one;

	public String getOne() {
		return one;
	}

	public void setOne(String one) {
		this.one = one;
	}

}
