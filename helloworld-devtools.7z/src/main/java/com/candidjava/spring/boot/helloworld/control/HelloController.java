package com.candidjava.spring.boot.helloworld.control;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.candidjava.spring.boot.helloworld.model.TestObject;
import com.candidjava.spring.boot.helloworld.model.TestObjectPrime;
import com.github.dozermapper.core.Mapper;

@Controller
public class HelloController {
	@Inject
	Mapper mapper;

	@RequestMapping(value = "/")
	String home() {
		System.out.println(mapper);
		TestObject testObject = new TestObject();
		testObject.setOne("yes");
		TestObjectPrime testObjectPrime = mapper.map(testObject, TestObjectPrime.class);
		System.out.println(testObjectPrime.getOnePrime());
		return "Hello candid ...!";
	}
}
